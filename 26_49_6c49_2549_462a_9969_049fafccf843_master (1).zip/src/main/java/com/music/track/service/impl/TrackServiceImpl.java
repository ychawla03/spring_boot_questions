package com.music.track.service.impl;

import com.music.track.dto.TrackRequest;
import com.music.track.model.Track;
import com.music.track.repository.TrackRepository;
import com.music.track.service.TrackService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class TrackServiceImpl implements TrackService {

    @Autowired
    private TrackRepository trackRepository;

    @Override
    public Track createTrack(TrackRequest trackRequest) {
        Track track = new Track();
        track.setAlbumName(trackRequest.albumName());
        track.setPlayCount(trackRequest.playCount());
        track.setTitle(trackRequest.title());
        return trackRepository.save(track);
 
    }
    @Override
    public List<Track> getAllTracks() {
        return trackRepository.findAll();
    }

    @Override
    public void deleteTrack(Long trackId) {
        trackRepository.deleteById(trackId);
    }

    @Override
    public List<Track> sortedTracks() {
        List<Track> sortedTrack = trackRepository.findAll();
        sortedTrack.sort(Comparator.comparing(Track::getTitle));
        return sortedTrack;
    }
}
