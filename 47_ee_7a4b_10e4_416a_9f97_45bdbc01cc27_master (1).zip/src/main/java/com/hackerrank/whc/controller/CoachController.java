package com.hackerrank.whc.controller;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.whc.model.Coach;
import com.hackerrank.whc.repository.CoachRepository;

@RestController
@RequestMapping("/api/coach")
public class CoachController {

    final CoachRepository coachRepository;

    public CoachController(CoachRepository coachRepository) {
        this.coachRepository = coachRepository;
    }
    @PostMapping
    public ResponseEntity<Coach> creatCoach(@RequestBody Coach coach)
    {
        Coach c = coachRepository.save(coach);
        return ResponseEntity.status(HttpStatus.CREATED).body(c);
    }

    @GetMapping
    public ResponseEntity<List<Coach>> getCoachById(){

     List<Coach> coach = coachRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));

     //coach.stream().sorted(Comparator.comparingInt(Coach::getId)).toList();
     
     return ResponseEntity.status(HttpStatus.OK).body(coach);
    }
@GetMapping("/{id}")
public ResponseEntity <Optional<Coach>>getById(@PathVariable Integer id){
Optional<Coach>coachObj=coachRepository.findById(id);
if(coachObj.isPresent()){
    return ResponseEntity.ok(coachObj);
}
else{
    return ResponseEntity.status(HttpStatus.NOT_FOUND)
    .body((null));
}
}



}
