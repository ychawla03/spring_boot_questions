package com.hackerrank.whc.controller;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.whc.model.Coach;
import com.hackerrank.whc.model.Customer;
import com.hackerrank.whc.repository.CoachRepository;
import com.hackerrank.whc.repository.CustomerRepository;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    final CustomerRepository customerRepository;

    final CoachRepository coachRepository;

    public CustomerController(CustomerRepository customerRepository, CoachRepository coachRepository) {
        this.customerRepository = customerRepository;
        this.coachRepository = coachRepository;
    }

    @PostMapping
    public ResponseEntity<Customer> create(@RequestBody Customer cust)
    {
        if(null != cust.getCoach() ){
        Optional<Coach> coach = coachRepository.findById(cust.getCoach().getId());
        if(coach.isPresent()){
            cust.setCoach(coach.get());
        }else{
            cust.setCoach(null);
        }
    }

        Customer user= customerRepository.save(cust);
        return ResponseEntity.status(HttpStatus.CREATED).body(user);
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getallcustomer()
    {
        List<Customer> customer= customerRepository.findAll().stream().sorted(Comparator.comparingInt(Customer::getId)).toList();
      return ResponseEntity.status(200).body(customer);
    }


    @GetMapping("/{id}")
    public  ResponseEntity<Optional<Customer>>getCustomerById(@PathVariable Integer id)
    {
        Optional<Customer> cust= customerRepository.findById(id);
        if(cust.isPresent()){
            return ResponseEntity.status(200).body(cust);
     }
     else{
        return ResponseEntity.status(404).build();
     }
    }
}
