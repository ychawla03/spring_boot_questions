package com.music.playlist.dto;

public record PlayListRequest(String name,
                              Integer tracksCount ) {
}
