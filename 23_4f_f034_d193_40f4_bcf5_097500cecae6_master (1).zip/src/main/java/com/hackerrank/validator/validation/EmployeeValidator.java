package com.hackerrank.validator.validation;

import com.hackerrank.validator.model.Employee;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class EmployeeValidator implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        return Employee.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object employeeObject, Errors errors) {
        Employee employee = (Employee) employeeObject;

       
        if(employee.getFullName() == null ||
            employee.getFullName().trim().isEmpty()){
                errors.rejectValue("fullName", "",
                "The fullName is a mandatory field");
            }

            if(employee.getMobileNumber() == null ||
            employee.getMobileNumber() == 0L){
                errors.rejectValue("mobileNumber", "mobileNumber.empty",
                "The mobileNumber is a mandatory field");
            }else if(employee.getMobileNumber() < 1_000_000_000L ||
            employee.getMobileNumber() > 9_999_999_999L){
                errors.rejectValue("mobileNumber", "",
                "The mobileNumber is a mandatory field");
            }

            if(employee.getEmailId() == null ||
            employee.getEmailId().trim().isEmpty()){
                errors.rejectValue("emailId", "emailId.empty",
                "The emailId is a mandatory field");
            }else if(!employee.getEmailId().contains("@")){
                errors.rejectValue("emailId", "",
                "The emailId should be in a valid email format");
            }

             if(employee.getDateOfBirth() == null ||
            employee.getDateOfBirth().trim().isEmpty()){
                errors.rejectValue("dateOfBirth", "",
                "The dateOfBirth is a mandatory field");
            }else{
                try{
                    DateTimeFormatter formatter = 
                DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate.parse(employee.getDateOfBirth());
                }catch(DateTimeParseException e){
                    errors.rejectValue("dateOfBirth", "",
                "The dateOfBirth should be in YYYY-MM-DD format");
                }
            }
    }
}
