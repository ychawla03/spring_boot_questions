package com.hackerrank.stocktrades.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.stocktrades.model.StockTrade;
import com.hackerrank.stocktrades.repository.StockTradeRepository;

@RestController
@RequestMapping("/trades")
public class StockTradeRestController {

  @Autowired
  private StockTradeRepository stockTradeRepository;


  @PostMapping
  public ResponseEntity<StockTrade> create(@RequestBody StockTrade stocktrade)
  {
    //return ResponseEntity.status(201).body(stockTradeRepository.save(stocktrade));
    return new ResponseEntity<>(stocktrade, HttpStatus.CREATED);

  }
  
  @GetMapping
  public ResponseEntity<List<StockTrade>> getAllStocks(){
    return ResponseEntity.ok(stockTradeRepository.findAll());
    //return ResponseEntity.ok(stockTradeRepository.findAll(Sort.by(Sort.Direction.ASC, "id")));
    //return stockTradeRepository.findAll()
    //.stream().sorted((a,b) -> Integer.compare(a.getId(),b.getId()))
    //.toList();

  }

  @GetMapping("/{id}")
  public ResponseEntity<Optional<StockTrade>> getDataById(@PathVariable ("id") Integer id){
    Optional<StockTrade> obj = stockTradeRepository.findById(id);
    if (obj.isEmpty()){
      return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
    return ResponseEntity.status(HttpStatus.OK).body(obj);
  }

  @RequestMapping(value = "/{id}", method = {RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.PATCH})
  public ResponseEntity<Void> methodNotAllowed(){
    return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);
  }

}
