package com.hackerrank.gevents.controller;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.gevents.model.Event;
import com.hackerrank.gevents.repository.EventRepository;

@RestController
public class EventController {

  @Autowired
  private EventRepository eventRepository;

  @PostMapping("/events")
  public ResponseEntity<Event> createEvent(@RequestBody Event event){
    Event created = eventRepository.save(event);
    return ResponseEntity.status(HttpStatus.CREATED).body(created);
  }

  @GetMapping("/events")
  public ResponseEntity<List<Event>> getAll(){
    List<Event> e = eventRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));
    return ResponseEntity.status(HttpStatus.OK).body(e);
  }

  @GetMapping("/repos/{repoId}/events")
  public ResponseEntity<List<Event>> getEventByRepoId(@PathVariable Integer repoId){
   List<Event> event =  eventRepository.findByRepoIdEquals(repoId);
   if(event.isEmpty()){
      return ResponseEntity.status(HttpStatus.NOT_FOUND)
          .build();
   }
   return ResponseEntity.ok(event);
  }
@GetMapping("/events/{id}")
public ResponseEntity<Optional<Event>> getById(@PathVariable Integer id)
{
 Optional< Event> e = eventRepository.findById(id);
if(e.isPresent())
{
  return ResponseEntity.status(HttpStatus.OK).body(e);
}

  return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
}
}
