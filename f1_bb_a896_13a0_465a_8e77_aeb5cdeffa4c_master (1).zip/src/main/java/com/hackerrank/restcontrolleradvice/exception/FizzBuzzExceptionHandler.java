package com.hackerrank.restcontrolleradvice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hackerrank.restcontrolleradvice.dto.BuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzBuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzException;
import com.hackerrank.restcontrolleradvice.dto.GlobalError;

@RestControllerAdvice
public class FizzBuzzExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(BuzzException.class)
  public ResponseEntity<GlobalError> 
  handleBuzzException(BuzzException ex){
    GlobalError error =new GlobalError();
    error.setMessage(ex.getMessage());
    error.setErrorReason(ex.getErrorReason());
    return new ResponseEntity<GlobalError>(error, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(FizzException.class)
  public ResponseEntity<GlobalError> handleFizzException(FizzException ex){
    GlobalError error = new GlobalError();
    error.setMessage(ex.getMessage());
    error.setErrorReason(ex.getErrorReason());
    return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
  }

   @ExceptionHandler(FizzBuzzException.class)
  public ResponseEntity<GlobalError> 
  handleFizzBuzzException(FizzBuzzException ex){
    GlobalError  error = new GlobalError();
    error.setMessage(ex.getMessage());
    error.setErrorReason(ex.getErrorReason());
    return new ResponseEntity<GlobalError>(error, HttpStatus.INSUFFICIENT_STORAGE);
    
  }
}
